# ECE-1140-Group-5
ECE 1140 Systems and Project Engineering

Group Members:
- Grant Davis
- Hannah Grigg
- Jason Matuszak
- Zach Kubitz
- Brian Arrington
- Jash Patel
- Matthew Kevicki
