#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

int main ()
{
	ofstream inputFile;
	inputFile.open("InputFile.txt");
	
	ifstream outputFile;
	outputFile.open("OutputFile.txt");
	
	cout << "Executing test case #1" << endl;
	
	inputFile << "CTC_Office_Inputs" << endl;
	inputFile << "TrackSwitch = true" << endl;
	inputFile << "Authority = 30" << endl;
	inputFile << "SuggestedTrainSpeed = 35" << endl;
	inputFile << "TrainDestination = Pitt" << endl;
	inputFile << "Track_Model_Inputs" << endl;
	inputFile << "isTrackDisabled = true" << endl;
	inputFile << "isTrainOnTrack = true" << endl;
	inputFile << "isTrackCrossingOn = false" << endl;
	inputFile << "trainID = 2556" << endl;
	inputFile << "TrackPosition = left" << endl;
	
	cout << "Testing Outputs..." << endl;
	
	string str = "";
	
	getline(outputFile, str);
	
	if(str != "CTC_Office_Outputs")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "TrainDestination = Pitt")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "TrainId = 2556")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrainOnTrack = true")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrackDisabled = true")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "Track_Model_Outputs")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrackDisabled = true")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrainOnTrack = true")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrainOnTrack = true")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "isTrackCrossingOn = false")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	getline(outputFile, str);
	
	if(str != "TrackPosition = left")
	{
		cout << "Test case #1 Failed" << endl;
	}
	
	cout << "Test case #1 Success" << endl;
	
	return 0;
}















