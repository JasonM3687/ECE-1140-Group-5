#include <iostream>
#include "SerialPort.cpp"
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <sstream>
#include <cstring>

using namespace std;

char* portName = "\\\\.\\COM3";

#define MAX_DATA_LENGTH 255

char incomingData[MAX_DATA_LENGTH];

//Control signals for turning on and turning off the led
//Check arduino code
//char word[] = "hello\n";

//Arduino SerialPort object
SerialPort *arduino;

//Blinking Delay
const unsigned int BLINKING_DELAY = 1000;

string boolToString(bool thing)
{
		if(thing == true)
		{
			return "true;";
		}
		else
		{
			return "false;";
		}		
}	

void printChar(char*c)
{
	for(int i = 0; i < strlen(c); i++)
	{
		std::cout << c[i];
	}	
	std::cout << "" << std::endl;
}	

int main()
{
	//track controls
	bool trackSwitch = false;
	string trackPosition = "";

	//outputs to ctc office
	double authority = 10;
	double trainSpeed = 10;
	string trainDestination = "";
	bool isThereABrokenRail = false;
	bool isThereATrain = false;
	bool isTrackCrossing = false;
	double trainID = 0;
	string TrackPosition = "";
	
	//open input file
	fstream inputFile;
	inputFile.open("InputFile.txt");
		
	//open outputfile
	fstream outputFile;
	outputFile.open("OutputFile.txt");
	
	string str0 = "";
	
	//make sure correct input file
	getline(inputFile,str0);
	if(str0 == "CTC_Office_Inputs")
	{
		std::cout << "accpted InputFile" << std::endl;
	}
	else
	{
		std::cout << "invalid InputFile" << std::endl;
	}	
	
	//start ardunio serial communcation
    arduino = new SerialPort(portName);

	//make sure arduino is connected
	if (arduino->isConnected())
	{
        std::cout  << std::endl << "Connection established at port " << portName << std::endl;
        std::cout << "   " << std::endl;
    }
    
    //char word[] = "hello\n";

	//while(true)
    //{
		string str2;
		string str3;
		string str4;
		
		while(getline(inputFile,str2))
		{
			std::stringstream ss;
			
			ss << str2;
			ss >> str3 >> str4;
			
			if(str2 != "Track_Model_Inputs")
			{
				if(str3 == "TrackSwitch")
				{
					string str5;
					ss >> str5;
					
					if(str5 == "true")
					{
						trackSwitch = 1;
					}	
					else if(str5 == "false")
					{
						trackSwitch = 0;
					}	
				}
				
				if(str3 == "Authority")
				{
					ss >> authority;
				}
				
				if(str3 == "SuggestedTrainSpeed")
				{
					ss >> trainSpeed;
				}
				
				if(str3 == "TrainDestination")
				{
					ss >> trainDestination;
				}
				
				if(str3 == "isTrackDisabled")
				{
					string str5;
					ss >> str5;
					
					if(str5 == "true")
					{
						isThereABrokenRail = 1;
					}	
					else if(str5 == "false")
					{
						isThereABrokenRail = 0;
					}
				}
				
				if(str3 == "isTrainOnTrack")
				{
					string str5;
					ss >> str5;
					
					if(str5 == "true")
					{
						isThereATrain = 1;
					}	
					else if(str5 == "false")
					{
						isThereATrain = 0;
					}
				}
				
				if(str3 == "isTrackCrossingOn")
				{
					string str5;
					ss >> str5;
					
					if(str5 == "true")
					{
						isTrackCrossing = 1;
					}	
					else if(str5 == "false")
					{
						isTrackCrossing = 0;
					}
				}
				
				if(str3 == "trainID")
				{
					ss >> trainID;
				}
				
				if(str3 == "TrackPosition")
				{
					ss >> TrackPosition;
				}
			}
		}
		
		//send data to arduino
		string tempString0 = boolToString(trackSwitch);
		char charTrackSwitch[tempString0.length()+1];
		strcpy(charTrackSwitch, tempString0.c_str());
		std::cout << tempString0 << endl;
		//printChar(charTrackSwitch);
		
		string tempString1 = std::to_string(authority);
		tempString1.append(";");
		char charAuthority[tempString1.length()+1];
		strcpy(charAuthority, tempString1.c_str());
		std::cout << tempString1 << endl;
		//printChar(charAuthority);
		
		string tempString2 = std::to_string(trainSpeed);
		tempString2.append(";");
		char charSuggestedTrainSpeed[tempString2.length()+1];
		strcpy(charSuggestedTrainSpeed, tempString2.c_str());
		std::cout << tempString2 << endl;
		//printChar(charSuggestedTrainSpeed);
		
		string tempString3 = trainDestination;
		tempString3.append(";");
		char charTrainDestination[tempString3.length()+1];
		strcpy(charTrainDestination, tempString3.c_str());
		std::cout << tempString3 << endl;
		//printChar(charTrainDestination);
		
		string tempString4 = boolToString(isThereABrokenRail);
		char charisTrackDisabled[tempString4.length()+1];
		strcpy(charisTrackDisabled, tempString4.c_str());
		std::cout << tempString4 << endl;
		//printChar(charisTrackDisabled);
		
		string tempString5 = boolToString(isThereATrain);
		char charisTrainOnTrack[tempString5.length()+1];
		strcpy(charisTrainOnTrack, tempString5.c_str());
		std::cout << tempString5 << endl;
		//printChar(charisTrainOnTrack);
		
		string tempString6 = boolToString(isTrackCrossing);
	    char charIsTrackCrossing[tempString6.length()+1];
	    strcpy(charIsTrackCrossing,tempString6.c_str());
		std::cout << tempString6 << endl;
		//printChar(charIsTrackCrossing);
		
		string tempString7 = std::to_string(trainID);
		tempString7.append(";");
		char charTrainID[tempString7.length()+1];
		strcpy(charTrainID, tempString7.c_str());
		std::cout << tempString7 << endl;
		//printChar(charTrainID);
		
		string tempString8 = TrackPosition;
		tempString8.append(";");
		char charTrackPosition[tempString8.length()+1];
		strcpy(charTrackPosition, tempString8.c_str());
		std::cout << tempString8 << endl;
		//printChar(charTrackPosition);
		
		std::cout << "------------------" << endl;
		
		char send[(tempString0.length()+1) + (tempString1.length()+1) + (tempString1.length()+1) + (tempString3.length()+1) + (tempString4.length()+1) + (tempString5.length()+1) + (tempString6.length()+1) + (tempString7.length()+1) + (tempString8.length()+1)];
		
		tempString0.append(tempString1);
		tempString0.append(tempString2);
		tempString0.append(tempString3);
		tempString0.append(tempString4);
		tempString0.append(tempString5);
		tempString0.append(tempString6);
		tempString0.append(tempString7);
		tempString0.append(tempString8);
		
		strcpy(send,tempString0.c_str());
		
		arduino->writeSerialPort(send, MAX_DATA_LENGTH);
		Sleep(20);
		
		outputFile << "CTC_Office_Outputs\n";
		outputFile << "TrainDestination = " << trainDestination << "\n";
		outputFile << "TrainId = " << trainID << "\n";
		outputFile << "isTrainOnTrack = "  << std::boolalpha << isThereATrain << "\n";
		outputFile << "isTrackDisabled = " << std::boolalpha << isThereABrokenRail << "\n";
		outputFile << "Track_Model_Outputs" << "\n";
		outputFile << "isTrackDisabled = " << std::boolalpha << isThereABrokenRail << "\n";
		outputFile << "isTrainOnTrack = " << std::boolalpha << isThereATrain << "\n";
		outputFile << "isTrackCrossingOn = " << std::boolalpha << isTrackCrossing << "\n";
		outputFile << "TrackPosition = " << TrackPosition << "\n";
		
	//}
	
	//while(true)
	//{
		//arduino->readSerialPort(incomingData, MAX_DATA_LENGTH);
		//printf("%s", incomingData);
		//Sleep(10);
	//}	
	
	inputFile.close();
	outputFile.close();
}
