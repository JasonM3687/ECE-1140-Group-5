from PyQt5 import QtCore, QtGui, QtWidgets
import time
from PyQt5.QtCore import QDateTime, Qt, QTime, QDate
import SWTrackControllerNew
import serial

class IOProgram(object):

        def SWTrackController(self, obj):
                self.SWTrack=obj
                self.routedBlocks =  self.SWTrack.getRoutedBlocksGreen()
                self.routedAuth = self.SWTrack.getRoutedAuthGreen()
                self.routedSuggestedSpeed = self.SWTrack.getRoutedSuggestedSpeedGreen()
                self.blockOccupancies = self.SWTrack.getRoutedBlockOccupancies()
                self.faultStatus = self.SWTrack.getRoutedFaultStatus()
                self.underGround = self.SWTrack.getRoutedUnderGround()
                self.routedBlockString = ""
                self.routedAuthString = ""
                self.routedSuggestedSpeedString = ""
                self.blockOccupanciesString = ""
                self.faultStatusString = ""
                self.underGroundString = ""
                self.timer = QtCore.QTimer()
                self.timer.timeout.connect(self.update)
                self.timer.start(200)
                ser = serial.Serial('COM3', baudrate = 9600, bytesize = serial.EIGHTBITS, parity = serial.PARITY_NONE, timeout = 2)
        
        def update(self):
                self.routedBlockString = ""
                self.routedAuthString = ""
                self.routedSuggestedSpeedString = ""
                self.blockOccupanciesString = ""
                self.faultStatusString = ""
                self.underGroundString = ""
                self.routedBlocks =  self.SWTrack.getRoutedBlocksGreen()
                self.routedAuth = self.SWTrack.getRoutedAuthGreen()
                self.routedSuggestedSpeed = self.SWTrack.getRoutedSuggestedSpeedGreen()
                self.blockOccupancies = self.SWTrack.getRoutedBlockOccupancies()
                self.faultStatus = self.SWTrack.getRoutedFaultStatus()
                self.underGround = self.SWTrack.getRoutedUnderGround()

                for i in range(len(self.routedBlocks)):
                        self.routedBlockString += str(self.routedBlocks[i])
                        self.routedBlockString += ","
                        self.routedAuthString += str(int(self.routedAuth[i]))
                        self.routedAuthString += ","
                        self.routedSuggestedSpeedString += str(int(self.routedSuggestedSpeed[i]))
                        self.routedSuggestedSpeedString += ","
                        if self.blockOccupancies:
                                self.blockOccupanciesString += str(self.blockOccupancies[i])
                                self.blockOccupanciesString += ","
                                self.faultStatusString += str(self.faultStatus[i])
                                self.faultStatusString += ","
                                self.underGroundString += str(self.underGround[i])
                                self.underGroundString += ","

                self.routedBlockString = self.routedBlockString[:-1]
                self.routedAuthString = self.routedAuthString[:-1]
                self.routedSuggestedSpeedString = self.routedSuggestedSpeedString[:-1]
                self.blockOccupanciesString = self.blockOccupanciesString[:-1]
                self.faultStatusString = self.faultStatusString[:-1]
                self.underGroundString = self.underGroundString[:-1]
                
                self.routedBlockString += ";"
                self.routedAuthString += ";"
                self.routedSuggestedSpeedString += ";"
                self.blockOccupanciesString += ";"
                self.faultStatusString += ";"
                self.underGroundString += ";"

                print(self.routedBlockString)
                print(self.routedAuthString)
                print(self.routedSuggestedSpeedString)
                print(self.blockOccupanciesString)
                print(self.faultStatusString)
                print(self.underGroundString)

                ser.write(self.routedAuthString.encode("utf-8"))
                #self.ser.write(self.routedSuggestedSpeedString.encode())
                #self.ser.write(self.blockOccupanciesString.encode())
                #self.ser.write(self.faultStatusString.encode())
                #self.ser.write(self.underGroundString.encode())

                
